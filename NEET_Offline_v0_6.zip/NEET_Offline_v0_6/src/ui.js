/* NEET Offline — UI. Plain DOM, no libraries, no network. Every data change goes through mutate() after an explicit user action. */
(function () {
  'use strict';
  const C = window.Core, D = window.NEET_DATA, $ = (s) => document.querySelector(s);
  const KEY = 'neet_offline_state_v1', SNAP = 'neet_offline_snapshots_v1';
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const now = () => new Date(), todayISO = () => C.toISO(now()), nowMin = () => now().getHours() * 60 + now().getMinutes();
  const fmtShort = (iso) => C.fromISO(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  const fmt = (iso) => iso ? C.fromISO(iso).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }) : '—';

  /* ---------- storage (localStorage, with in-memory fallback that is announced loudly) ---------- */
  const mem = {}; let persistent = true;
  try { localStorage.setItem('__t', '1'); localStorage.removeItem('__t'); } catch (e) { persistent = false; }
  const sget = (k) => { try { return persistent ? localStorage.getItem(k) : (mem[k] == null ? null : mem[k]); } catch (e) { return null; } };
  const sset = (k, v) => { try { if (persistent) localStorage.setItem(k, v); else mem[k] = v; return true; } catch (e) { persistent = false; mem[k] = v; return false; } };
  let loadError = null;
  function loadState() {
    const raw = sget(KEY);
    if (!raw) return C.emptyState();
    try { const s = JSON.parse(raw); return { ...C.emptyState(), ...s }; }
    catch (e) { loadError = 'Saved data could not be read. It has NOT been overwritten; restore from a recovery copy in Settings.'; sset(KEY + '_corrupt_' + Date.now(), raw); return C.emptyState(); }
  }
  let state = loadState();
  const snaps = () => { try { return JSON.parse(sget(SNAP) || '[]'); } catch (e) { return []; } };
  function snapshot(reason, force) {
    const json = JSON.stringify(state), list = snaps(), d = todayISO();
    if (!force && list.length && list[list.length - 1].date === d) return;
    list.push({ date: d, ts: now().toISOString(), reason, checksum: C.checksum(json), json });
    while (list.length > 5) list.shift();
    sset(SNAP, JSON.stringify(list));
  }
  function save() { if (!loadError || state.seq > 1) { snapshot('daily'); } sset(KEY, JSON.stringify(state)); }
  function mutate(fn) { fn(state); state.seq = (state.seq || 1) + 1; save(); render(); }
  const nextId = () => (state.seq || 1) * 1000 + Math.floor(Math.random() * 999);

  /* ---------- ui state (not persisted) ---------- */
  let tab = 'today', chSubject = 'Physics', chSearch = '', expanded = null, testCal = 'UTTE', testOpen = null;
  let chatDate = todayISO(), draft = '', pending = [], modal = null, locked = !!(state.settings && state.settings.pinHash), planStart = todayISO(), flash = null;
  const TABS = [['today', 'Today'], ['plan', 'Plan'], ['chat', 'Reports'], ['chapters', 'Chapters'], ['tests', 'Tests'], ['settings', 'Settings']];

  /* ---------- views ---------- */
  function blockRow(b, cur) {
    const cls = ['blk', b.kind === 'conflict' ? 'bad' : '', b.kind === 'class' ? 'cls' : '', cur ? 'cur' : ''].join(' ');
    const cancel = b.source === 'user_entry' && b.id ? ` <button class="lnk" data-act="cancelEntry" data-id="${b.id}">cancel</button>` : '';
    return `<div class="${cls}"><span class="t">${C.hm(b.start)}–${C.hm(b.end)}</span><span class="l">${esc(b.label)}${b.prot && b.kind !== 'conflict' ? ' <i title="protected">●</i>' : ''}${cancel}</span><span class="d">${C.dur(b.end - b.start)}</span></div>`;
  }
  function nextTestsHtml() {
    return ['UTTE', 'AAKASH'].map((cal) => {
      const u = C.upcomingTests(D.tests, state, todayISO(), cal, 3);
      const nm = cal === 'UTTE' ? 'UT / TE calendar (Physics, Chemistry)' : 'Aakash calendar';
      return `<div class="sub">${nm}</div>` + (u.length ? u.map((x) => `<div class="row"><b>${esc(x.t.id)}</b><span>${fmt(x.d)}</span><span class="d">${C.daysBetween(todayISO(), x.d)} d</span></div>`).join('') : '<div class="muted">none dated</div>');
    }).join('');
  }
  function viewToday() {
    const t = todayISO(), blocks = C.dayBlocks(state, t), nm = nowMin(), f = C.todayFocus(D, state, t, nm);
    const issues = C.validate(blocks);
    let focus;
    if (f.mode === 'none') focus = '<div class="muted">No chapters from tests in the next 21 days need a next step, or no study time is left today.</div>';
    else if (f.mode === 'one') focus = (f.tasks.length ? taskLine(f.tasks[0]) : '<div class="muted">No task fits the time left today.</div>') +
      `<div class="muted">${f.overloaded} chapters are due but only ${C.dur(f.avail)} of study time is left, so only the single highest-priority task is shown.</div>`;
    else focus = f.tasks.map(taskLine).join('');
    return `<section class="card hero"><div class="big">${C.daysToExam(t)} days</div><div>to NEET UG on 2 May 2027 · target above 700</div></section>
    <section class="card"><h3>Focus now</h3>${focus}</section>
    <section class="card"><h3>Today · ${fmt(t)}</h3>
      <div class="muted">Free study left: <b>${C.dur(C.remainingStudy(blocks, nm))}</b> · whole day: ${C.dur(C.studyMinutes(blocks))} · protected revision: ${C.dur(C.revisionMinutes(blocks))}</div>
      ${issues.length ? `<div class="warn">${issues.map(esc).join('<br>')}</div>` : ''}
      ${blocks.map((b) => blockRow(b, b.start <= nm && nm < b.end)).join('')}
      <div class="muted">● protected block. Add extra classes in Reports, e.g. “2:30pm to 3:45pm = Biology C”.</div></section>
    <section class="card"><h3>Next tests</h3>${nextTestsHtml()}</section>`;
  }
  function taskLine(t) {
    return `<div class="task"><b>${esc(t.subject)} · ${esc(t.chapter)}</b><div>Next step: ${esc(C.MS_LABEL[t.step])} · ${t.minutes} min</div><div class="muted">${esc(t.test)} on ${fmt(t.testDate)}</div></div>`;
  }
  function planDays(p, compact) {
    return p.days.map((d) => `<div class="pday"><b>${fmt(d.date)}</b>` + (d.slots.length ? d.slots.map((s) => `<div class="row"><span class="t">${C.hm(s.start)}–${C.hm(s.end)}</span><span class="l">${s.task ? esc(s.task.subject) + ' · ' + esc(s.task.chapter) + ' — ' + esc(C.MS_LABEL[s.task.step]) + ' <span class="muted">(' + esc(s.task.test) + ')</span>' : '<span class="muted">unallocated — your choice</span>'}</span></div>`).join('') : '<div class="muted">no free study time</div>') + (d.issues && d.issues.length ? `<div class="warn">${d.issues.map(esc).join('<br>')}</div>` : '') + '</div>').join('');
  }
  function viewPlan() {
    const plans = state.plans || [], approved = plans.filter((p) => p.status === 'approved').slice(-1)[0], prop = state.proposal;
    return `<section class="card"><h3>Weekly plan</h3>
      <div class="muted">The whole week is generated first. Nothing becomes your plan until you approve it, and an approved plan is never changed silently.</div>
      <div class="rowf"><label>Start date <input type="date" id="planStart" value="${esc(planStart)}"></label><button class="btn" data-act="genPlan">Generate 7-day plan</button></div></section>
    ${prop ? `<section class="card prop"><h3>Proposed plan — NOT approved</h3><div class="muted">Generated ${esc(prop.generated.slice(0, 16).replace('T', ' '))} for ${fmt(prop.startDate)}</div>
      <ul class="assump">${prop.assumptions.map((a) => `<li>${esc(a)}</li>`).join('')}</ul>${planDays(prop)}
      <div class="muted">${prop.notScheduled} chapter(s) due soon do not fit this week.</div>
      <div class="rowf"><button class="btn pri" data-act="approvePlan">Approve this plan</button><button class="btn" data-act="discardPlan">Discard</button></div></section>` : ''}
    ${approved ? `<section class="card"><h3>Approved plan</h3><div class="muted">Approved ${esc(approved.approvedAt.slice(0, 16).replace('T', ' '))} · from ${fmt(approved.startDate)} · ${plans.length} plan(s) kept in history</div>${planDays(approved)}</section>` : '<section class="card muted">No approved plan yet.</section>'}`;
  }
  function viewChat() {
    const msgs = (state.reports || []).map((r) => `<div class="msg"><div>${esc(r.body).replace(/\n/g, '<br>')}</div><div class="muted">${esc(r.ts.slice(0, 16).replace('T', ' '))}</div></div>`).join('') || '<div class="muted">Type a study report or a coaching entry such as “2:30pm to 3:45pm = Biology C”. Reports are stored exactly as typed; they never tick any chapter milestone.</div>';
    const cards = pending.map((p, n) => pendingCard(p, n)).join('');
    return `<section class="card"><div class="rowf"><label>Coaching entries apply to <input type="date" id="chatDate" value="${esc(chatDate)}"></label></div></section>
      <div class="chat" id="chatlist">${msgs}</div>${cards}
      <div class="compose"><textarea id="draft" rows="2" placeholder="Report or schedule entry">${esc(draft)}</textarea><button class="btn pri" data-act="send">Send</button></div>`;
  }
  function wouldConflict(date, start, end, subject) {
    const es = (state.entries || []).filter((e) => e.date === date && e.status === 'active');
    return C.applyEntries(C.baseRoutine(), es.concat([{ start, end, subject }])).some((b) => b.kind === 'conflict');
  }
  function pendingCard(p, n) {
    const i = p.i; let body;
    const conflict = i.start != null && wouldConflict(p.date, i.start, i.end, i.subject);
    if (i.status === 'ok' || i.status === 'needs_confirmation') {
      body = `<div><b>I read it as ${C.hm(i.start)}–${C.hm(i.end)} · ${esc(i.subject)}</b> on ${fmt(p.date)}</div>${i.notes.map((x) => `<div class="muted">${esc(x)}</div>`).join('')}
        ${conflict ? '<div class="warn">This overlaps a protected block or another typed class and would show as a CONFLICT.</div>' : ''}
        <div class="rowf"><button class="btn pri" data-act="confirmEntry" data-n="${n}">Confirm</button><button class="btn" data-act="editPending" data-n="${n}">Edit</button><button class="lnk" data-act="ignorePending" data-n="${n}">Ignore</button></div>`;
    } else if (i.status === 'ambiguous') {
      body = `<div><b>More than one reading fits — choose one for “${esc(i.subject)}”:</b></div><div class="rowf">${i.candidates.map((c, k) => `<button class="btn" data-act="pickCand" data-n="${n}" data-k="${k}">${C.hm(c[0])}–${C.hm(c[1])}${wouldConflict(p.date, c[0], c[1], i.subject) ? ' ⚠ overlaps a protected block' : ''}</button>`).join('')}<button class="lnk" data-act="ignorePending" data-n="${n}">Ignore</button></div>`;
    } else body = `<div class="warn">${i.notes.map(esc).join('; ')}</div><div class="rowf"><button class="btn" data-act="editPending" data-n="${n}">Edit</button><button class="lnk" data-act="ignorePending" data-n="${n}">Ignore</button></div>`;
    return `<div class="card pend"><div class="muted">You typed: ${esc(i.source)}</div>${body}</div>`;
  }
  function chapterRows() {
    const ms = C.milestoneState(state), q = chSearch.trim().toLowerCase(), t = todayISO();
    return D.chapters.filter((c) => c.subject === chSubject && (!q || c.chapter.toLowerCase().includes(q))).map((c) => {
      const done = C.doneSet(ms, c.key), open = expanded === c.key;
      const status = done.size ? done.size + '/8' : 'Not started';
      let inner = '';
      if (open) {
        const nxt = C.nextStep(c.subject, done);
        const tests = D.tests.map((x) => ({ x, d: C.testDate(x, state) })).filter((o) => o.d && o.d >= t && !o.x.complete && o.x.mapped.includes(c.chapter)).sort((a, b) => (a.d < b.d ? -1 : 1)).slice(0, 3);
        inner = C.MILESTONES.map(([k, l]) => `<label class="ms"><input type="checkbox" data-act="toggleMs" data-key="${esc(c.key)}" data-ms="${k}" ${done.has(k) ? 'checked' : ''}> ${esc(l)}</label>`).join('') +
          `<div class="muted">Suggested next step: ${nxt ? esc(C.MS_LABEL[nxt]) : 'all listed steps ticked'}. Ticks are only ever set by you.</div>` +
          (tests.length ? `<div class="muted">Next tests: ${tests.map((o) => esc(o.x.id) + ' ' + fmt(o.d)).join(' · ')}</div>` : '');
      }
      return `<div class="card ch"><div class="chh" data-act="expand" data-key="${esc(c.key)}"><span>${esc(c.chapter)}</span><span class="muted">${status}</span></div>${inner}</div>`;
    }).join('') || '<div class="muted">No chapter matches.</div>';
  }
  function viewChapters() {
    return `<div class="chips">${C.SUBJECTS.map((s) => `<button class="chip ${s === chSubject ? 'on' : ''}" data-act="subj" data-s="${s}">${s}</button>`).join('')}</div>
      <input id="chSearch" class="search" placeholder="Search chapter" value="${esc(chSearch)}"><div id="chlist">${chapterRows()}</div>`;
  }
  function viewTests() {
    const list = D.tests.filter((t) => t.cal === testCal).map((t) => ({ t, d: C.testDate(t, state) })).sort((a, b) => (a.d || '9') < (b.d || '9') ? -1 : 1), td = todayISO();
    const hdr = testCal === 'UTTE' ? 'Revised UT & TE planner (RMPLUS/OYM Pro). Subjects listed: Physics, Chemistry (Mathematics is ignored; there is no Biology syllabus in this calendar).' : 'Aakash Repeater Course Phase-03 test planner. Meridian tests span 2–3 days; the first day is shown.';
    return `<div class="chips"><button class="chip ${testCal === 'UTTE' ? 'on' : ''}" data-act="cal" data-c="UTTE">UT / TE</button><button class="chip ${testCal === 'AAKASH' ? 'on' : ''}" data-act="cal" data-c="AAKASH">Aakash</button></div>
      <div class="muted pad">${hdr}</div>` + list.map(({ t, d }) => {
      const open = testOpen === t.id, over = (state.testDates || {})[t.id];
      const left = d ? C.daysBetween(td, d) : null, st = d == null ? 'date not given' : left < 0 ? 'done ' + (-left) + ' d ago' : left === 0 ? 'TODAY' : 'in ' + left + ' d';
      let inner = '';
      if (open) inner = Object.entries(t.wording).map(([s, w]) => `<div><b>${s}:</b> ${esc(w)}</div>`).join('') +
        `<div class="sub">Mapped chapters (from your workbook — verify)</div><div>${t.complete ? 'Complete syllabus' : t.mapped.map(esc).join(' · ')}</div>` +
        t.flags.map((f) => `<div class="warn small">⚠ ${esc(f)}</div>`).join('') +
        `<div class="rowf"><label>Test date <input type="date" id="td_${esc(t.id)}" value="${esc(d || '')}"></label><button class="btn" data-act="saveTestDate" data-id="${esc(t.id)}">Save date</button>${over ? `<button class="lnk" data-act="resetTestDate" data-id="${esc(t.id)}">use PDF date</button>` : ''}</div>` +
        `<div class="muted">${over ? 'Date changed by you; PDF says ' + (t.date ? fmt(t.date) : 'no date') + '.' : 'Date as in the PDF.'}</div>`;
      return `<div class="card ch"><div class="chh" data-act="openTest" data-id="${esc(t.id)}"><span><b>${esc(t.id)}</b> <span class="muted">${esc(t.mode)}</span></span><span>${fmt(d)}${t.end ? ' – ' + fmtShort(t.end) : ''} <span class="muted">${st}</span></span></div>${inner}</div>`;
    }).join('');
  }
  function viewSettings() {
    const list = snaps(), pin = !!(state.settings && state.settings.pinHash);
    return `<section class="card"><h3>Storage</h3>
      <div>${persistent ? '✓ Data is saved on this device inside the app’s browser storage.' : '<span class="warn">⚠ Storage is unavailable here: changes will be LOST when this page closes. Export a backup now, or use the installed Android app.</span>'}</div>
      <div class="muted">Entries: ${(state.entries || []).length} · reports: ${(state.reports || []).length} · milestone events: ${(state.milestones || []).length} · plans: ${(state.plans || []).length}</div></section>
    <section class="card"><h3>Backup</h3><div class="muted">Backups are checksummed files. Export regularly (browser storage can be cleared by the system).</div>
      <div class="rowf"><button class="btn pri" data-act="exportBackup">Export backup</button><label class="btn">Import backup<input type="file" id="importFile" accept=".json,application/json" hidden></label><button class="btn" data-act="exportCsv">Export milestones (CSV)</button></div></section>
    <section class="card"><h3>Recovery copies (last 5)</h3>${list.length ? list.slice().reverse().map((s, k) => `<div class="row"><span>${esc(s.ts.slice(0, 16).replace('T', ' '))} · ${esc(s.reason)} · ${esc(s.checksum)}</span><button class="lnk" data-act="restoreSnap" data-k="${list.length - 1 - k}">restore</button></div>`).join('') : '<div class="muted">None yet.</div>'}</section>
    <section class="card"><h3>PIN lock</h3><div class="muted">A casual lock against curious eyes. It is not encryption.</div>
      <div class="rowf"><input id="pin" type="password" inputmode="numeric" maxlength="8" placeholder="${pin ? 'new PIN' : 'choose PIN (4–8 digits)'}"><button class="btn" data-act="setPin">${pin ? 'Change PIN' : 'Set PIN'}</button>${pin ? '<button class="lnk" data-act="clearPin">remove PIN</button>' : ''}</div></section>
    <section class="card"><h3>Excel workbook</h3><div class="muted">This app keeps its own data and never opens, edits or replaces your workbook. Workbook write-back is not built; use the CSV export to copy milestones across by hand.</div></section>
    <section class="card"><h3>About</h3><div class="muted">NEET Offline v0.6 · no network code, no accounts, no analytics. Verified here: logic tests and a headless-browser test. Not yet verified: your tablet, airplane mode on the device, 4 GB RAM behaviour.</div></section>`;
  }
  function viewLock() { return `<div class="lock"><h2>NEET Offline</h2><input id="unlock" type="password" inputmode="numeric" placeholder="PIN" autofocus><button class="btn pri" data-act="unlock">Unlock</button><div class="warn" id="lockmsg"></div></div>`; }

  function modalHtml() {
    if (!modal) return '';
    return `<div class="overlay"><div class="dlg"><h3>${esc(modal.title)}</h3><div>${esc(modal.text)}</div><div class="rowf"><button class="btn pri" data-act="modalOk">${esc(modal.ok || 'Confirm')}</button><button class="btn" data-act="modalCancel">Cancel</button></div></div></div>`;
  }
  function render() {
    const app = $('#app');
    if (locked) { app.innerHTML = viewLock(); return; }
    const views = { today: viewToday, plan: viewPlan, chat: viewChat, chapters: viewChapters, tests: viewTests, settings: viewSettings };
    const banners = (!persistent ? '<div class="banner">Storage unavailable: changes will be lost on close. Export a backup.</div>' : '') + (loadError ? `<div class="banner">${esc(loadError)}</div>` : '') + (flash ? `<div class="banner ok">${esc(flash)}</div>` : '');
    app.innerHTML = `<main>${banners}${views[tab]()}</main><nav>${TABS.map(([k, l]) => `<button class="${k === tab ? 'on' : ''}" data-act="tab" data-t="${k}">${l}</button>`).join('')}</nav>${modalHtml()}`;
    if (tab === 'chat') { const l = $('#chatlist'); if (l) l.scrollTop = l.scrollHeight; }
  }

  /* ---------- download / upload (Android bridge when present, otherwise browser) ---------- */
  function download(name, mime, text) {
    if (window.AndroidBridge && window.AndroidBridge.saveFile) { window.AndroidBridge.saveFile(name, mime, text); return; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: mime })); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  const stamp = () => now().toISOString().slice(0, 16).replace(/[:T]/g, '-');
  function csv() {
    const ms = C.milestoneState(state), head = ['Subject', 'Chapter'].concat(C.MILESTONES.map((m) => m[1]));
    const q = (s) => '"' + String(s).replace(/"/g, '""') + '"';
    return [head.map(q).join(',')].concat(D.chapters.map((c) => { const d = C.doneSet(ms, c.key); return [c.subject, c.chapter].map(q).concat(C.MILESTONES.map((m) => (d.has(m[0]) ? 'Y' : ''))).join(','); })).join('\n');
  }
  function say(m) { flash = m; render(); setTimeout(() => { if (flash === m) { flash = null; render(); } }, 4000); }

  /* ---------- actions ---------- */
  const actions = {
    tab: (el) => { tab = el.dataset.t; render(); },
    subj: (el) => { chSubject = el.dataset.s; expanded = null; render(); },
    expand: (el) => { expanded = expanded === el.dataset.key ? null : el.dataset.key; render(); },
    cal: (el) => { testCal = el.dataset.c; testOpen = null; render(); },
    openTest: (el) => { testOpen = testOpen === el.dataset.id ? null : el.dataset.id; render(); },
    toggleMs: (el) => {
      const key = el.dataset.key, m = el.dataset.ms, want = el.checked, ch = D.chapters.find((c) => c.key === key);
      el.checked = !want; // revert visually until confirmed
      modal = { title: 'Confirm', text: `Mark “${C.MS_LABEL[m]}” as ${want ? 'completed' : 'NOT completed'} for ${ch.chapter}?`, ok: 'Confirm',
        fn: () => mutate((s) => s.milestones.push({ id: nextId(), key, ms: m, done: want, ts: now().toISOString() })) };
      render();
    },
    modalOk: () => { const f = modal && modal.fn; modal = null; if (f) f(); else render(); },
    modalCancel: () => { modal = null; render(); },
    send: () => {
      const text = ($('#draft').value || '').trim(); if (!text) return;
      draft = ''; const date = chatDate;
      pending = pending.concat(text.split('\n').filter((l) => C.hasTimeRange(l)).map((l) => ({ i: C.interpretEntry(l), date })));
      mutate((s) => s.reports.push({ id: nextId(), ts: now().toISOString(), body: text }));
    },
    confirmEntry: (el) => addEntry(Number(el.dataset.n)),
    pickCand: (el) => { const p = pending[Number(el.dataset.n)], c = p.i.candidates[Number(el.dataset.k)]; p.i = { ...p.i, status: 'ok', start: c[0], end: c[1], notes: [] }; addEntry(Number(el.dataset.n)); },
    ignorePending: (el) => { pending.splice(Number(el.dataset.n), 1); render(); },
    editPending: (el) => { const p = pending.splice(Number(el.dataset.n), 1)[0]; draft = p.i.source; render(); },
    cancelEntry: (el) => { const id = Number(el.dataset.id); modal = { title: 'Cancel entry', text: 'Cancel this typed class? It is kept in history but no longer applied.', ok: 'Cancel entry', fn: () => mutate((s) => { const e = s.entries.find((x) => x.id === id); if (e) { e.status = 'cancelled'; e.cancelledAt = now().toISOString(); } }) }; render(); },
    saveTestDate: (el) => { const id = el.dataset.id, v = ($('#td_' + id).value || ''); if (v && !C.isISO(v)) return say('Invalid date'); mutate((s) => { s.testDates = s.testDates || {}; if (v) s.testDates[id] = v; else delete s.testDates[id]; }); },
    resetTestDate: (el) => mutate((s) => { delete s.testDates[el.dataset.id]; }),
    genPlan: () => { const start = ($('#planStart').value || todayISO()); if (!C.isISO(start)) return say('Invalid start date'); planStart = start;
      const p = C.generateWeekPlan(D, state, start, 7, 21, start === todayISO() ? nowMin() : null);
      const slim = { startDate: p.startDate, generated: now().toISOString(), assumptions: p.assumptions, notScheduled: p.notScheduled.length, days: p.days.map((d) => ({ date: d.date, issues: d.issues, slots: d.slots.map((s) => ({ start: s.start, end: s.end, task: s.task && { subject: s.task.subject, chapter: s.task.chapter, step: s.task.step, test: s.task.test, key: s.task.key } })) })) };
      mutate((s) => { s.proposal = slim; }); },
    discardPlan: () => mutate((s) => { s.proposal = null; }),
    approvePlan: () => { modal = { title: 'Approve plan', text: 'Approve this 7-day plan? Earlier approved plans stay in history.', ok: 'Approve', fn: () => mutate((s) => { (s.plans || []).forEach((p) => { if (p.status === 'approved') p.status = 'superseded'; }); s.plans.push({ ...s.proposal, id: nextId(), status: 'approved', approvedAt: now().toISOString() }); s.proposal = null; }) }; render(); },
    exportBackup: () => { download('neet-offline-backup-' + stamp() + '.json', 'application/json', C.makeBackup(state, now().toISOString())); say('Backup exported'); },
    exportCsv: () => { download('neet-milestones-' + stamp() + '.csv', 'text/csv', csv()); say('CSV exported'); },
    restoreSnap: (el) => { const s = snaps()[Number(el.dataset.k)]; modal = { title: 'Restore recovery copy', text: `Replace current data with the copy from ${s.ts.slice(0, 16).replace('T', ' ')}? Current data is saved as a new recovery copy first.`, ok: 'Restore', fn: () => { snapshot('before restore', true); try { state = { ...C.emptyState(), ...JSON.parse(s.json) }; save(); say('Restored'); } catch (e) { say('Recovery copy unreadable; nothing changed'); } } }; render(); },
    setPin: () => { const v = $('#pin').value; if (!/^\d{4,8}$/.test(v)) return say('PIN must be 4–8 digits'); const salt = Math.random().toString(36).slice(2); mutate((s) => { s.settings = { ...s.settings, salt, pinHash: C.simpleHash(v, salt) }; }); say('PIN set'); },
    clearPin: () => { modal = { title: 'Remove PIN', text: 'Remove the PIN lock?', ok: 'Remove', fn: () => mutate((s) => { delete s.settings.pinHash; delete s.settings.salt; }) }; render(); },
    unlock: () => { const v = $('#unlock').value; if (C.simpleHash(v, state.settings.salt) === state.settings.pinHash) { locked = false; render(); } else $('#lockmsg').textContent = 'Wrong PIN'; },
  };
  function addEntry(n) {
    const p = pending[n]; if (!p || p.i.start == null) return; pending.splice(n, 1);
    mutate((s) => s.entries.push({ id: nextId(), date: p.date, start: p.i.start, end: p.i.end, subject: p.i.subject, source: p.i.source, confirmedAt: now().toISOString(), status: 'active' }));
  }

  document.addEventListener('click', (e) => { const el = e.target.closest('[data-act]'); if (!el || el.tagName === 'INPUT' && el.type === 'checkbox') return; const f = actions[el.dataset.act]; if (f) f(el); });
  document.addEventListener('change', (e) => {
    const el = e.target;
    if (el.dataset && el.dataset.act === 'toggleMs') return actions.toggleMs(el);
    if (el.id === 'planStart') planStart = el.value; if (el.id === 'chatDate' && C.isISO(el.value)) chatDate = el.value;
    if (el.id === 'importFile' && el.files[0]) el.files[0].text().then((t) => {
      let b; try { b = C.parseBackup(t); } catch (err) { return say(err.message); }
      modal = { title: 'Import backup', text: `Replace ALL current data with this backup (${b.reports.length} reports, ${b.entries.length} entries, ${b.milestones.length} milestone events)? Current data is saved as a recovery copy first.`, ok: 'Import', fn: () => { snapshot('before import', true); state = b; save(); say('Backup imported'); } };
      render();
    });
  });
  document.addEventListener('input', (e) => {
    if (e.target.id === 'draft') draft = e.target.value;
    if (e.target.id === 'chSearch') { chSearch = e.target.value; $('#chlist').innerHTML = chapterRows(); }
  });
  window.__neet = { get state() { return state; }, render };  // read-only handle for tests/debugging
  render();
})();
