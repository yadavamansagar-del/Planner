/* NEET Offline — deterministic core. No DOM, no network, no storage. Runs in the browser and in Node (tests).
   Times are minutes since midnight. Dates are local ISO strings 'YYYY-MM-DD'. */
(function (root) {
  'use strict';
  const WINDOW_START = 5 * 60, WINDOW_END = 22 * 60, MAX_INFERRED = 360;
  const SUBJECTS = ['Physics', 'Chemistry', 'Botany', 'Zoology'];
  const EXAM_DATE = '2027-05-02';
  const MILESTONES = [
    ['learning_in_progress', 'Learning in progress'], ['first_reading_completed', 'First reading completed'],
    ['ncert_completed', 'NCERT completed'], ['formulae_revised', 'Formulae revised'],
    ['question_practice_completed', 'Question practice completed'], ['doubts_addressed', 'Doubts addressed'],
    ['revision_completed', 'Revision completed'], ['test_performance_reviewed', 'Test performance reviewed'],
  ];
  const hm = (m) => String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
  const dur = (m) => Math.floor(m / 60) + 'h ' + String(m % 60).padStart(2, '0') + 'm';

  /* ---------- dates ---------- */
  const pad = (n) => String(n).padStart(2, '0');
  const toISO = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const fromISO = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (s, n) => { const d = fromISO(s); d.setDate(d.getDate() + n); return toISO(d); };
  const daysBetween = (a, b) => Math.round((fromISO(b) - fromISO(a)) / 86400000);
  const daysToExam = (today) => daysBetween(today, EXAM_DATE);
  const isISO = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && toISO(fromISO(s)) === s;

  /* ---------- typed schedule entries (port of planner_core.py; verified against golden vectors) ---------- */
  const RANGE_RE = /(\d{1,2})(?::(\d{2}))?\s*([ap]\.?m\.?)?\s*(?:to|[-–—])\s*(\d{1,2})(?::(\d{2}))?\s*([ap]\.?m\.?)?/i;
  const accepted = (m) => !!m && !!(m[3] || m[6] || (m[2] && m[5]));
  const hasTimeRange = (line) => accepted(RANGE_RE.exec(line.trim()));
  const normAp = (a) => (a ? a.toLowerCase().replace(/\./g, '') : null);
  function hourOptions(h, ap) {
    if (ap) { if (h < 1 || h > 12) return []; return [(h % 12) + (ap === 'pm' ? 12 : 0)]; }
    if (h === 0 || (h >= 13 && h <= 23)) return [h];
    if (h >= 1 && h <= 12) return [h % 12, (h % 12) + 12];
    return [];
  }
  const strip = (s, chars) => { let a = 0, b = s.length; while (a < b && chars.includes(s[a])) a++; while (b > a && chars.includes(s[b - 1])) b--; return s.slice(a, b); };
  const lstrip = (s, c) => { let a = 0; while (a < s.length && c.includes(s[a])) a++; return s.slice(a); };
  const rstrip = (s, c) => { let b = s.length; while (b > 0 && c.includes(s[b - 1])) b--; return s.slice(0, b); };
  const interp = (status, start, end, subject, source, candidates, notes) =>
    ({ status, start, end, subject, source, candidates: candidates || [], notes: notes || [] });

  function interpretEntry(line) {
    const text = line.trim();
    const m = RANGE_RE.exec(text);
    if (!accepted(m)) return interp('error', null, null, '', text, [], ['No time range found']);
    const left = text.slice(0, m.index).trim();
    const right = lstrip(text.slice(m.index + m[0].length).trim(), '=:- ').trim();
    const subject = right || rstrip(left, ' =:-').trim();
    if (!subject) return interp('error', null, null, '', text, [], ['Needs a subject or class label']);
    const m1 = Number(m[2] || 0), m2 = Number(m[5] || 0);
    if (m1 > 59 || m2 > 59) return interp('error', null, null, subject, text, [], ['Invalid minutes']);
    const sOpts = hourOptions(Number(m[1]), normAp(m[3])), eOpts = hourOptions(Number(m[4]), normAp(m[6]));
    if (!sOpts.length || !eOpts.length) return interp('error', null, null, subject, text, [], ['Invalid hour']);
    if (sOpts.length === 1 && eOpts.length === 1) {
      const s = sOpts[0] * 60 + m1, e = eOpts[0] * 60 + m2;
      if (e <= s) return interp('error', null, null, subject, text, [], ['End time must be later than start time on the same day']);
      return interp('ok', s, e, subject, text);
    }
    const cands = [];
    for (const sh of sOpts) for (const eh of eOpts) {
      const s = sh * 60 + m1, e = eh * 60 + m2, d = e - s;
      if (d > 0 && d <= MAX_INFERRED && s >= WINDOW_START && e <= WINDOW_END) cands.push([s, e]);
    }
    if (!cands.length) return interp('error', null, null, subject, text, [], ['No reading fits between 05:00 and 22:00']);
    if (cands.length === 1) return interp('needs_confirmation', cands[0][0], cands[0][1], subject, text, cands, ['am/pm not given; only one reading fits the day']);
    return interp('ambiguous', null, null, subject, text, cands, ['am/pm not given; more than one reading fits the day']);
  }

  /* ---------- timetable ---------- */
  const B = (s, e, label, kind, prot) => ({ start: s * 60, end: e * 60, label, kind, prot: !!prot, source: 'routine' });
  const T = (h, m) => h + m / 60;
  function baseRoutine() {
    const b = (h1, m1, h2, m2, label, kind, prot) => ({ start: h1 * 60 + m1, end: h2 * 60 + m2, label, kind, prot: !!prot, source: 'routine' });
    return [
      b(5, 0, 6, 0, 'Free time', 'personal'), b(6, 0, 7, 0, 'Formula recall and handwritten revision', 'revision', 1),
      b(7, 0, 9, 0, 'Morning extra study', 'study'), b(9, 0, 9, 30, 'Buffer', 'buffer'), b(9, 30, 10, 0, 'Breakfast', 'meal', 1),
      b(10, 0, 11, 0, 'Travel to coaching', 'travel', 1), b(11, 0, 11, 15, 'Arrival buffer', 'buffer'),
      b(11, 15, 12, 30, 'Coaching class 1', 'class_default'), b(12, 30, 12, 45, 'Class gap', 'gap'),
      b(12, 45, 14, 0, 'Coaching class 2', 'class_default'), b(14, 0, 14, 30, 'Lunch', 'meal', 1),
      b(14, 30, 15, 45, 'Coaching class 3', 'class_default'), b(15, 45, 18, 0, 'Coaching self-study / doubts', 'study'),
      b(18, 0, 19, 0, 'Return travel', 'travel', 1), b(19, 0, 19, 30, 'Dinner', 'meal', 1), b(19, 30, 20, 0, 'Free time', 'personal'),
      b(20, 0, 21, 0, "Evening revision of today's learning", 'revision', 1), b(21, 0, 21, 30, 'Evening extra study', 'study'),
      b(21, 30, 22, 0, 'Free time / prepare for bed', 'personal'),
    ];
  }
  const overlap = (a, b) => a.start < b.end && b.start < a.end;
  function applyEntries(routine, entries) {
    let blocks = routine.map((x) => ({ ...x }));
    for (const e of entries) {
      if (e.start == null || e.end == null) throw new Error('Entry has no resolved time; confirm the interpretation first');
      const nb = { start: e.start, end: e.end, label: e.subject, kind: 'class', prot: true, source: 'user_entry', id: e.id };
      if (blocks.some((b) => overlap(b, nb) && b.prot)) { blocks.push({ ...nb, label: 'CONFLICT — ' + e.subject, kind: 'conflict' }); continue; }
      const out = [];
      for (const old of blocks) {
        if (!overlap(old, nb)) { out.push(old); continue; }
        if (old.start < nb.start) out.push({ ...old, end: nb.start });
        if (nb.end < old.end) out.push({ ...old, start: nb.end });
      }
      blocks = out.concat([nb]);
    }
    const idx = new Map(blocks.map((b, i) => [b, i]));
    return blocks.sort((a, b) => a.start - b.start || a.end - b.end || (a.kind < b.kind ? -1 : a.kind > b.kind ? 1 : 0) || idx.get(a) - idx.get(b));
  }
  function validate(blocks) {
    const o = blocks.slice().sort((a, b) => a.start - b.start || a.end - b.end), issues = [];
    for (let i = 0; i < o.length; i++) for (let j = i + 1; j < o.length; j++) {
      if (o[j].start >= o[i].end) break;
      if (overlap(o[i], o[j])) issues.push(hm(o[i].start) + '-' + hm(o[i].end) + ' overlaps ' + hm(o[j].start) + '-' + hm(o[j].end));
    }
    return issues;
  }
  const sumKind = (blocks, k) => blocks.filter((b) => b.kind === k).reduce((s, b) => s + (b.end - b.start), 0);
  const studyMinutes = (blocks) => sumKind(blocks, 'study');
  const revisionMinutes = (blocks) => sumKind(blocks, 'revision');
  function remainingStudy(blocks, nowMin) {
    return blocks.filter((b) => b.kind === 'study').reduce((s, b) => s + Math.max(0, b.end - Math.max(b.start, nowMin)), 0);
  }
  function dayBlocks(state, date) {
    const es = (state.entries || []).filter((e) => e.date === date && e.status === 'active');
    return applyEntries(baseRoutine(), es);
  }

  /* ---------- chapters / milestones ---------- */
  function milestoneState(state) {
    const latest = {};
    for (const ev of state.milestones || []) (latest[ev.key] = latest[ev.key] || {})[ev.ms] = !!ev.done;
    return latest;
  }
  const doneSet = (ms, key) => new Set(Object.entries(ms[key] || {}).filter(([, v]) => v).map(([k]) => k));
  /* The next un-ticked step in a fixed study pipeline. A SUGGESTION only: never written anywhere. */
  function nextStep(subject, done) {
    const order = ['first_reading_completed', 'ncert_completed', 'formulae_revised', 'question_practice_completed', 'doubts_addressed', 'revision_completed', 'test_performance_reviewed'];
    for (const s of order) {
      if (s === 'formulae_revised' && !(subject === 'Physics' || subject === 'Chemistry')) continue;
      if (!done.has(s)) return s;
    }
    return null;
  }
  const MS_LABEL = Object.fromEntries(MILESTONES);

  /* ---------- tests ---------- */
  function testDate(t, state) { return ((state.testDates || {})[t.id]) || t.date; }
  function upcomingTests(tests, state, today, cal, n) {
    return tests.filter((t) => t.cal === cal).map((t) => ({ t, d: testDate(t, state) })).filter((x) => x.d && x.d >= today)
      .sort((a, b) => (a.d < b.d ? -1 : a.d > b.d ? 1 : 0)).slice(0, n || 3);
  }

  /* ---------- tasks and weekly plan ---------- */
  const SESSION = 60;
  /* Chapters in the mapped scope of tests dated in [from, from+horizon], ordered by earliest test; each carries its next step. */
  function buildTasks(data, state, from, horizon) {
    const ms = milestoneState(state), byName = new Map();
    const chapters = data.chapters;
    const first = new Map();
    for (const t of data.tests) {
      const d = testDate(t, state);
      if (!d || d < from || daysBetween(from, d) > horizon) continue;
      const names = t.complete ? [] : t.mapped;  // complete-syllabus mocks are not used to prioritise chapters
      for (const n of names) if (!first.has(n) || d < first.get(n).d) first.set(n, { d, id: t.id });
    }
    const tasks = [];
    for (const ch of chapters) {
      const f = first.get(ch.chapter);
      if (!f) continue;
      const done = doneSet(ms, ch.key), step = nextStep(ch.subject, done);
      if (!step) continue;
      tasks.push({ key: ch.key, subject: ch.subject, chapter: ch.chapter, step, test: f.id, testDate: f.d, minutes: SESSION });
    }
    const so = (s) => SUBJECTS.indexOf(s);
    tasks.sort((a, b) => (a.testDate < b.testDate ? -1 : a.testDate > b.testDate ? 1 : 0) || so(a.subject) - so(b.subject) || (a.chapter < b.chapter ? -1 : 1));
    return tasks;
  }
  /* Whole proposal for N days. Fills each day's free study blocks in priority order. Nothing is saved or approved here. */
  function generateWeekPlan(data, state, startDate, days, horizon, fromMin) {
    days = days || 7; horizon = horizon || 21;
    const tasks = buildTasks(data, state, startDate, horizon);
    let qi = 0; const plan = [];
    for (let i = 0; i < days; i++) {
      const date = addDays(startDate, i), blocks = dayBlocks(state, date), slots = [];
      for (const b of blocks.filter((x) => x.kind === 'study')) {
        let cur = b.start;
        if (i === 0 && fromMin != null) cur = Math.max(cur, Math.ceil(fromMin / 5) * 5);  // never schedule into the past
        while (b.end - cur >= 30) {
          const t = tasks[qi];
          if (!t) { slots.push({ start: cur, end: b.end, task: null }); break; }
          const len = Math.min(SESSION, b.end - cur);
          slots.push({ start: cur, end: cur + len, task: { ...t, minutes: len } });
          if (len === SESSION) qi++; else { /* short slot: partial session, chapter stays queued */ }
          cur += len;
        }
      }
      plan.push({ date, blocks, slots, issues: validate(blocks) });
    }
    const ms = milestoneState(state), untouched = tasks.filter((t) => doneSet(ms, t.key).size === 0).length;
    const progressNote = untouched ? [untouched + ' of ' + tasks.length + ' due chapters have no milestone ticked, so they start at "First reading completed". Tick what you have already finished in Chapters, then regenerate.'] : [];
    return { startDate, days: plan, notScheduled: tasks.slice(qi), totalTasks: tasks.length,
      assumptions: progressNote.concat(['The standard daily routine applies to every day unless you have confirmed typed entries for that date.',
        'Coaching holidays and extra classes are not known to the app; enter them before approving.',
        'Each slot is a 60-minute session on the chapter\'s next un-ticked step. A chapter may need several sessions; nothing is marked complete.',
        'Chapters come from tests dated within ' + horizon + ' days (complete-syllabus mocks ignored). Chapter mapping is from your workbook; verify flagged tests.']) };
  }
  /* If everything fits in the time left today show the list; otherwise recommend exactly ONE task. */
  function todayFocus(data, state, today, nowMin) {
    const blocks = dayBlocks(state, today), avail = remainingStudy(blocks, nowMin);
    const tasks = buildTasks(data, state, today, 21), need = tasks.length * SESSION;
    const feasible = tasks.filter((t) => t.minutes <= avail);
    if (!tasks.length) return { mode: 'none', avail, tasks: [] };
    if (need <= avail) return { mode: 'all', avail, tasks };
    return { mode: 'one', avail, tasks: feasible.length ? [feasible[0]] : [], overloaded: tasks.length };
  }

  /* ---------- backup ---------- */
  function checksum(str) { // FNV-1a 32-bit over UTF-16 code units, hex. Integrity check, not security.
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
    return h.toString(16).padStart(8, '0');
  }
  function emptyState() { return { v: 1, reports: [], entries: [], milestones: [], plans: [], testDates: {}, settings: {}, seq: 1 }; }
  function makeBackup(state, nowISO) {
    const payload = JSON.stringify(state);
    return JSON.stringify({ app: 'neet-offline', format: 1, created: nowISO, checksum: checksum(payload), state: JSON.parse(payload) });
  }
  function parseBackup(text) {
    let o; try { o = JSON.parse(text); } catch (e) { throw new Error('Not a valid backup file (unreadable JSON)'); }
    if (!o || o.app !== 'neet-offline' || o.format !== 1 || !o.state) throw new Error('Not a NEET Offline backup (wrong app or format)');
    if (checksum(JSON.stringify(o.state)) !== o.checksum) throw new Error('Backup checksum mismatch: file is damaged or was edited');
    const s = o.state;
    for (const k of ['reports', 'entries', 'milestones', 'plans']) if (!Array.isArray(s[k])) throw new Error('Backup missing section: ' + k);
    return { ...emptyState(), ...s, testDates: s.testDates || {}, settings: s.settings || {} };
  }
  function simpleHash(pin, salt) { // casual lock only; NOT encryption
    return checksum(salt + ':' + pin) + checksum(pin + ':' + salt.split('').reverse().join(''));
  }
  const api = { SUBJECTS, EXAM_DATE, MILESTONES, MS_LABEL, hm, dur, toISO, fromISO, addDays, daysBetween, daysToExam, isISO,
    hasTimeRange, interpretEntry, baseRoutine, applyEntries, validate, studyMinutes, revisionMinutes, remainingStudy, dayBlocks,
    milestoneState, doneSet, nextStep, testDate, upcomingTests, buildTasks, generateWeekPlan, todayFocus,
    checksum, emptyState, makeBackup, parseBackup, simpleHash };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Core = api;
})(typeof window !== 'undefined' ? window : globalThis);
