# Technical audit and roadmap — 11 Nov 2026

Everything below was checked by running code or reading bytes in this session, unless marked **not verified**.

## 1. What was supplied vs. what was not
| Item | Status |
|---|---|
| v0.1, v0.2, v0.3, v0.4 bundles | Received and extracted |
| Original workbook | Received only inside the v0.3 bundle (`NEET_Planner_MASTER_ORIGINAL.xlsx`, SHA-256 `7024cdbe…b6de`, 13 sheets) |
| Corrected-date workbook | Inside v0.1 and v0.2 (identical, SHA-256 `42c37022…3cae`) |
| Revised UT & TE planner PDF | **Not supplied.** Only the v0.2 text extraction exists. PDF not independently inspected |
| Aakash Phase-03 PDF | **Not supplied.** Only the v0.2 text extraction exists. PDF not independently inspected |

## 2. Bundle structure
- **Not cumulative.** v0.3 has only the Excel module + master workbook; v0.4 has 5 files (registry + tests) and no workbook, seed data or planner.
- **Duplicates:** `planner_core.py`, `test_planner_core.py`, `SYSTEM_SPEC.md` and the corrected workbook are byte-identical in v0.1 and v0.2. The v0.2 ZIP's inner folder is still named `…_v0_1`. `.pytest_cache` directories shipped in v0.1 and v0.3.
- **No shared integration:** nothing imports across modules. v0.4 `core/__init__.py` exists; v0.3 core has none.
- v0.5 consolidates everything into one tree and ships no workbook copies (identify them by SHA-256 above).

## 3. Reported tests, independently re-run
| Release | Reported | Re-run here |
|---|---|---|
| v0.1 | 4 | 4 pass |
| v0.2 | 9 (includes v0.1's 4) | 9 pass |
| v0.3 | 5 + real-workbook test | 5 pass; real-workbook test reproduced (see §5) |
| v0.4 | 5; 84 chapters | 5 pass; 84 chapters confirmed (Physics 29, Chemistry 21, Botany 18, Zoology 16), no duplicate keys, workbook hash unchanged |

Caveat: pytest could not be installed offline, so a minimal stand-in runner (`tools/offline_pytest_shim/`) was used. It supports only `tmp_path` and `pytest.raises`. Please re-run with real pytest.

## 4. Defects and contradictions found
| # | Finding | Evidence | v0.5 action |
|---|---|---|---|
| 1 | **Your own example was mishandled.** `2:30pm to 3:45pm = Biology C` produced a false CONFLICT because default "Coaching class 3" was protected | Reproduced on v0.1 | Fixed: default classes are placeholders; typed entry labels the slot. Tested |
| 2 | Input without am/pm raised an error instead of showing an interpretation; 24-hour input unsupported | Reproduced | Fixed: `interpret_entry` returns ok / needs_confirmation / ambiguous / error; nothing is applied until confirmed |
| 3 | Subject-first entries (`Biology C = 2:30pm to 3:45pm`) were rejected with "needs a subject" | Reproduced on v0.1 | Fixed, tested |
| 4 | No function recalculated available study time when extra classes are added | Code read | Added `study_minutes` (285 min baseline; 195 after a 90-min extra class) |
| 5 | **Two incompatible milestone models.** v0.2 forces strict sequence; v0.4 allows independent milestones | Code read | v0.4 model kept (matches "independently"). v0.2 module moved to `docs/DEPRECATED_…` |
| 6 | v0.3 `read_cell` and patch used string-built XPath with weakly validated addresses | Probed | Strict A1 regex; injection-style addresses refused. Tested |
| 7 | Requirement "maintain transaction history" not met in v0.3 | Code read | Append-only JSONL journal added (optional `journal_path`). Tested |
| 8 | Registry imports chapters by hard-coded start row 5 and keys by lower-cased names; a renamed chapter becomes a new identity and orphans old events | Code read | **Open** (roadmap) |
| 9 | Registry opens SQLite connections via `with` but never closes them | Code read | Open (minor; irrelevant to Android port) |
| 10 | An explicit time outside 05:00–22:00 (e.g. `12am to 1am`) is accepted | Probed | Open; documented |
| 11 | v0.2 `VALIDATION.txt` shows the Android toolchain absent; no release ever built an APK | Read | Unchanged: still true |

## 5. Excel safety engine (v0.3) — verdict
**Sound for its stated scope.** Verified on a disposable copy of the real master:
- Patching an existing blank cell in `Doubts` (a sheet that carries the x14 data-validation extension): **exactly one OOXML part changed** (`sheet5.xml`); every other part byte-identical.
- After canonical-XML comparison, the patched sheet is identical except the target cell, including the `extLst` x14 validation. (Serialisation differs cosmetically: quote style and XML declaration.)
- Backup bytes equal the source; the original was untouched; `openpyxl` opens the candidate.
- Choice: keep the OOXML engine; do **not** use ordinary openpyxl saving.

Limitations still open:
1. **No activation/promotion step**: a candidate is created but nothing safely swaps it in.
2. **Stale formula caches**: patching an input cell leaves dependent cached values stale until Excel recalculates; `calcChain.xml` is present. The v0.1 date correction set recalc flags in `workbook.xml`; v0.3 does not.
3. **Dropdown validation is not enforced** on patched values (e.g. `Study status`).
4. Existing cells only. The nine-milestone schema needs new columns, so it needs a reviewed design and a candidate workbook first.
5. Needs Python + `lxml`; **neither runs natively on Android**, so this engine must be re-implemented in Kotlin (`java.util.zip` + XML pull parser) and re-verified against the real workbook.
6. Not verified in the Microsoft Excel Android app.

## 6. Workbook / calendar checks
- Corrected copy differs from master in exactly two parts (`sheet10.xml` = Tests, `workbook.xml`). Matches v0.1's claim.
- All 15 fixed-date UT/CT/TE rows in the corrected `Tests` sheet match the v0.2 UT/TE extraction; TE-1 is correctly blank ("Will be given as HA").
- Extraction text confirms the UT/TE calendar lists Physics/Chemistry/Mathematics only. Aakash IDs present: FT-01…09, AIATS-01…11, NBTS and Meridian entries.
- **Question for you:** `UTScores` records only Physics and Chemistry, but the UT/TE planner also lists Mathematics. Intentional?
- The Aakash extraction header reads "Total Marks: 180 (Each Subject)", which looks like a source/extraction wording quirk. Left untouched.
- UT/TE and Aakash **syllabus-to-chapter mapping has not been done** (v0.2 correctly refused to guess).
- The workbook already holds study dates/"Studied" statuses. v0.5 does **not** import them as milestones.

## 7. Android toolchain in this environment
Java runtime 21 only. No `javac` binary, Kotlin, Gradle, Android SDK, adb, or network. **An APK cannot be built here.** v0.5 is therefore a source project; see `README.md` for exactly what you need to build it.

## 8. Roadmap (recommendation; you decide)
| Release | Content | Why |
|---|---|---|
| **v0.5.1** | You build v0.5 in Android Studio, run `GoldenVectorsTest`, install on the tablet, send me compile errors/screenshots | Nothing in the Android code is verified until then |
| v0.6 | Weekly plan generator (shown in full, then waits for your approval) + typed-entry persistence by date | Your approval rule |
| v0.7 | SAF workbook link; Kotlin port of the OOXML engine + journal; backup status; activation flow | Highest-risk module; needs the real workbook as test fixture |
| v0.8 | Test calendars (UT/TE and Aakash kept separate) with source wording + mapping-confidence flags | Needs the two PDFs |
| v0.9 | Local PIN; airplane-mode and 4 GB RAM testing; first honest "offline validated" claim | Only after device tests |
| later | Workbook schema extension for nine milestones (reviewed candidate); optional OCR / local model | Optional modules |
