// Plugin versions are an UNVERIFIED selection (no Android toolchain was available when written). Accept Android Studio's upgrade suggestions.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
