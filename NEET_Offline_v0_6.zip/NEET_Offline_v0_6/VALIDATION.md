# Validation report — v0.6 (12 Nov 2026)

## Verified here (automated)
- **15 logic tests (Node):** time-entry interpretation and timetable overlay match the Python reference's golden vectors (18 inputs, 5 schedules); your example sentence; dates (171 days to 2 May 2027); milestone independence; task ordering; week-plan constraints (only free study slots, respects typed classes, never in the past, pure proposal); one-task rule; date overrides; backup round-trip and tamper detection.
- **31 checks in real headless Chromium** (1180×820 viewport, clock = 12 Nov 2026 10:00): every tab; confirm-before-apply for entries, milestones and plans; cancel keeps history; ambiguous time handling; conflict warnings; persistence across reload; backup export/import/tamper rejection; recovery copies; CSV (header + 84 rows); PIN set/wrong/right; **zero network requests**; works with the network switched off; outbound `fetch` blocked by the page policy; no JavaScript errors; Android-bridge export contract (simulated).
- **Data:** 84 chapters (29/21/18/16); 45 tests (16 UT/TE + 29 Aakash, matching the PDF's "29"); every date equals your workbook's Tests sheet; no Mathematics or Biology in the UT/TE calendar; every mapped chapter name exists.
- Two layout/logic defects were found by looking at real screenshots and fixed (wrapped times; plan including past slots), plus one gap (no overlap warning on ambiguous choices).

## NOT verified
- **Nothing was run on your tablet.** Verified browser is desktop Chromium on Linux, not Chrome/WebView on Android 16 or Samsung's software.
- **Persistence of an HTML file opened from Files on Android is unknown;** this is why backups are prominent.
- **The Android wrapper (`android/`) has never been compiled or run.** Gradle/Kotlin/SDK were unavailable. Plugin versions unverified.
- No on-device airplane-mode test, no 4 GB RAM/battery test. (Offline-ness is enforced in code, and shown in the headless run, but "validated on device" is not claimed.)
- PDFs were read from the text supplied in the conversation, not from the PDF files; wording was typed by hand from that text.
- The planner is a simple deterministic heuristic (earliest test first, 60-minute sessions, tests within 21 days). It is a proposal engine, not an optimiser.
- Excel workbook integration: not built.
