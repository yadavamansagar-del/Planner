// End-to-end test in real headless Chromium. Run: node tests/ui.e2e.js [path-to-NEET_Offline.html]
const { chromium } = require(process.env.PLAYWRIGHT_PATH || '/opt/npm-tools/node_modules/playwright');
const path = require('path'), fs = require('fs'), assert = require('node:assert/strict');
const Core = require('../src/core.js');
const FILE = 'file://' + path.resolve(process.argv[2] || path.join(__dirname, '..', 'NEET_Offline.html'));
let passed = 0; const ok = (name) => { passed++; console.log('PASS', name); };

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 820, height: 1180 }, acceptDownloads: true });
  const page = await ctx.newPage();
  const requests = [], errors = [];
  page.on('request', (r) => requests.push(r.url())); page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.clock.install({ time: new Date('2026-11-12T10:00:00') });
  await page.goto(FILE);
  const text = () => page.locator('#app').innerText();
  const tab = (name) => page.locator('nav button', { hasText: new RegExp('^' + name + '$') }).click();
  const state = () => page.evaluate(() => JSON.parse(JSON.stringify(window.__neet.state)));

  // 1 dashboard
  assert.match(await text(), /171 days/); assert.match(await text(), /2 May 2027/); ok('dashboard shows 171 days to 2 May 2027');
  assert.match(await text(), /Free study left/); assert.match(await text(), /Coaching class 3/); ok('daily timetable listed');
  assert.match(await text(), /only the single highest-priority task is shown/); assert.equal(await page.locator('.task').count(), 1); ok('overloaded day recommends exactly ONE task');

  // 2 chat: your example sentence
  await tab('Reports');
  await page.fill('#draft', 'Studied Chapter 3-4 of Biology today\n2:30pm to 3:45pm = Biology C'); await page.click('[data-act=send]');
  assert.match(await text(), /I read it as 14:30–15:45 · Biology C/);
  let s = await state(); assert.equal(s.entries.length, 0, 'nothing applied before confirmation'); assert.equal(s.reports.length, 1); assert.equal(s.milestones.length, 0);
  ok('typed entry is interpreted and waits for confirmation; report stored verbatim; no milestones touched');
  assert.equal(await page.locator('.pend').count(), 1, 'the "Chapter 3-4" line must not be treated as a time');
  await page.click('[data-act=confirmEntry]'); s = await state(); assert.equal(s.entries.length, 1); assert.equal(s.entries[0].date, '2026-11-12');
  await tab('Today'); let t = await text(); assert.doesNotMatch(t, /CONFLICT/); assert.match(t, /Biology C/); assert.match(t, /whole day: 4h 45m/); ok('confirmed entry labels the slot, no false conflict, study time = 4h 45m');
  // ambiguous
  await tab('Reports'); await page.fill('#draft', '7:00 to 8:00 = Physics'); await page.click('[data-act=send]');
  assert.equal(await page.locator('[data-act=pickCand]').count(), 2); assert.doesNotMatch(await page.locator('[data-act=pickCand]').nth(0).innerText(), /overlaps/); assert.match(await page.locator('[data-act=pickCand]').nth(1).innerText(), /overlaps a protected block/); s = await state(); assert.equal(s.entries.length, 1); ok('ambiguous time offers two choices and stores nothing');
  await page.locator('[data-act=pickCand]').nth(1).click(); s = await state(); assert.equal(s.entries.length, 2); assert.equal(s.entries[1].start, 19 * 60); ok('picking a reading stores that reading');
  // conflict with protected block is shown, not hidden
  await page.fill('#draft', '1:45pm to 2:45pm = Chemistry'); await page.click('[data-act=send]');
  assert.match(await text(), /would show as a CONFLICT/); await page.click('[data-act=ignorePending]'); ok('overlap with lunch is warned before confirming');
  // cancel an entry keeps history
  await tab('Today'); await page.locator('[data-act=cancelEntry]').first().click(); await page.click('[data-act=modalOk]'); s = await state();
  assert.equal(s.entries.length, 2); assert.equal(s.entries.filter((e) => e.status === 'cancelled').length, 1); ok('cancelling an entry keeps it in history (no deletion)');

  // 3 chapters + milestones
  await tab('Chapters'); assert.equal(await page.locator('.ch').count(), 29);
  await page.locator('.chh', { hasText: 'Work, Energy & Power' }).click();
  await page.locator('label.ms', { hasText: 'NCERT completed' }).locator('input').click(); await page.click('[data-act=modalCancel]');
  s = await state(); assert.equal(s.milestones.length, 0); ok('cancelling the confirmation changes nothing');
  await page.locator('label.ms', { hasText: 'NCERT completed' }).locator('input').click(); await page.click('[data-act=modalOk]');
  s = await state(); assert.equal(s.milestones.length, 1); assert.equal(s.milestones[0].ms, 'ncert_completed'); assert.equal(s.milestones[0].done, true);
  assert.equal(await page.locator('label.ms input:checked').count(), 1); ok('milestone set only after confirmation; others untouched (independent)');
  for (const [subj, n] of [['Chemistry', 21], ['Botany', 18], ['Zoology', 16]]) { await page.click(`[data-act=subj][data-s=${subj}]`); assert.equal(await page.locator('.ch').count(), n); }
  ok('84 chapters across four subjects (29/21/18/16)');

  // 4 tests: calendars separate, no Mathematics
  await tab('Tests'); t = await text(); assert.match(t, /UT-3/); assert.doesNotMatch(t, /FT-04/); assert.doesNotMatch(t, /Mathematics\b.*Trigon/);
  await page.locator('.chh', { hasText: 'TE-1' }).click(); assert.match(await text(), /date not given/); assert.match(await text(), /Will be given|PDF gives no date/);
  await page.fill('#td_TE-1', '2026-11-20'); await page.click('[data-act=saveTestDate]'); s = await state(); assert.equal(s.testDates['TE-1'], '2026-11-20'); ok('TE-1 date (given as HA) can be entered; stored as an override');
  await page.click('[data-act=cal][data-c=AAKASH]'); t = await text(); assert.match(t, /FT-04/); assert.doesNotMatch(t, /UT-3/); assert.equal(await page.locator('.ch').count(), 29);
  await page.locator('.chh', { hasText: 'Meridian-02' }).click(); assert.match(await text(), /8 Nov 2026 – 10 Nov/); assert.match(await text(), /Biological Classification-II: \(from Cyanobacteria to Lichens\)/);
  assert.match(await text(), /Source wording names part of a chapter/); ok('Aakash calendar separate, source wording preserved, uncertain mapping flagged');
  await tab('Today'); assert.match(await text(), /TE-2/); ok('today lists next tests per calendar');

  // 5 plan: proposal first, approval second
  await tab('Plan'); await page.click('[data-act=genPlan]'); s = await state(); assert.ok(s.proposal); assert.equal(s.plans.length, 0); assert.match(await text(), /Proposed plan — NOT approved/);
  assert.equal((s.proposal.days || []).length, 7); ok('7-day plan generated as a proposal; nothing approved yet');
  const before = JSON.stringify((await state()).entries);
  await page.click('[data-act=approvePlan]'); assert.match(await text(), /Approve this 7-day plan/); await page.click('[data-act=modalOk]'); s = await state();
  assert.equal(s.plans.length, 1); assert.equal(s.plans[0].status, 'approved'); assert.equal(s.proposal, null); assert.equal(JSON.stringify(s.entries), before); ok('plan approved only after confirmation; schedule entries untouched');
  await page.click('[data-act=genPlan]'); await page.click('[data-act=approvePlan]'); await page.click('[data-act=modalOk]'); s = await state();
  assert.deepEqual(s.plans.map((p) => p.status), ['superseded', 'approved']); ok('re-approval keeps the old plan as history (superseded, never deleted)');

  // 6 persistence across reload
  await page.reload(); s = await state(); assert.equal(s.entries.length, 2); assert.equal(s.milestones.length, 1); assert.equal(s.plans.length, 2); ok('data survives reload (localStorage)');

  // 7 backups
  await tab('Settings');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('[data-act=exportBackup]')]);
  const file = await dl.path(); const txt = fs.readFileSync(file, 'utf8'); const parsed = Core.parseBackup(txt);
  assert.equal(parsed.entries.length, 2); assert.match(dl.suggestedFilename(), /^neet-offline-backup-.*\.json$/); ok('backup exports as a checksummed file that parses and verifies');
  const bad = path.join(path.dirname(file), 'bad.json'); fs.writeFileSync(bad, txt.replace('Biology C', 'Biology X'));
  await page.setInputFiles('#importFile', bad); await page.waitForSelector('.banner.ok, .banner', { timeout: 3000 }); assert.match(await text(), /checksum mismatch/); s = await state(); assert.equal(s.entries.length, 2); ok('tampered backup rejected, data untouched');
  const good = path.join(path.dirname(file), 'good.json'); fs.writeFileSync(good, txt);
  await page.evaluate(() => { /* clear data to prove import restores it */ localStorage.removeItem('neet_offline_state_v1'); }); await page.reload();
  assert.equal((await state()).entries.length, 0); await tab('Settings'); await page.setInputFiles('#importFile', good); await page.waitForSelector('.dlg'); await page.click('[data-act=modalOk]');
  s = await state(); assert.equal(s.entries.length, 2); assert.equal(s.plans.length, 2); ok('import restores everything after confirmation');
  assert.match(await text(), /Recovery copies/); assert.ok(await page.locator('[data-act=restoreSnap]').count() >= 1); ok('recovery copies are kept and listed');
  const [dl2] = await Promise.all([page.waitForEvent('download'), page.click('[data-act=exportCsv]')]); const csv = fs.readFileSync(await dl2.path(), 'utf8').split('\n');
  assert.equal(csv.length, 85); assert.match(csv.find((l) => l.includes('Work, Energy')), /"Y"|Y/); ok('CSV export: header + 84 chapters, ticked milestone present');

  // 8 PIN
  await page.fill('#pin', '12'); await page.click('[data-act=setPin]'); assert.equal(((await state()).settings || {}).pinHash, undefined); ok('short PIN refused');
  await page.fill('#pin', '4821'); await page.click('[data-act=setPin]'); await page.reload(); assert.match(await text(), /Unlock/);
  await page.fill('#unlock', '0000'); await page.click('[data-act=unlock]'); assert.match(await text(), /Wrong PIN`?/);
  await page.fill('#unlock', '4821'); await page.click('[data-act=unlock]'); assert.match(await text(), /days/); ok('PIN lock: wrong PIN refused, right PIN opens');

  // 9 offline guarantee + visual check
  const external = requests.filter((u) => !u.startsWith('file:') && !u.startsWith('data:') && !u.startsWith('blob:')); assert.deepEqual(external, []); ok('zero network requests of any kind during the whole session');
  await ctx.setOffline(true); await page.reload(); assert.match(await text(), /Unlock|days/); ok('works with the network switched off');
  assert.deepEqual(errors, [], 'no console/page errors'); ok('no JavaScript errors');
  const csp = await page.evaluate(() => fetch('https://example.com').then(() => 'LEAK', (e) => 'blocked')); assert.equal(csp, 'blocked'); ok('page CSP blocks outbound fetch');
  await page.fill('#unlock', '4821'); await page.click('[data-act=unlock]'); await tab('Today'); await page.screenshot({ path: '/tmp/today.png' });
  await tab('Chapters'); await page.screenshot({ path: '/tmp/chapters.png' });

  // 10 Android bridge contract (simulated): export must go through AndroidBridge.saveFile when present
  const c2 = await browser.newContext(); const p2 = await c2.newPage();
  await p2.addInitScript(() => { window.AndroidBridge = { saveFile(n, m, t) { window.__saved = { n, m, t }; } }; });
  await p2.goto(FILE); await p2.locator('nav button', { hasText: /^Settings$/ }).click(); await p2.click('[data-act=exportBackup]');
  const saved = await p2.evaluate(() => window.__saved); assert.match(saved.n, /^neet-offline-backup-.*\.json$/); assert.equal(saved.m, 'application/json'); Core.parseBackup(saved.t);
  ok('Android bridge: export hands a valid, checksummed backup to AndroidBridge.saveFile'); await c2.close();
  console.log(`\nE2E: ${passed} checks passed`); await browser.close();
})().catch((e) => { console.error('E2E FAILED:', e.message.split('\n').slice(0, 6).join('\n')); process.exit(1); });
