const test = require('node:test'); const assert = require('node:assert/strict');
const C = require('../src/core.js'); const golden = require('./golden_planner.json'); const DATA = require('../src/data.json');

test('golden: interpretations match the Python reference', () => {
  for (const g of golden.interpretations) {
    const r = C.interpretEntry(g.input);
    assert.equal(C.hasTimeRange(g.input), g.has_time_range, 'has_time_range ' + g.input);
    assert.equal(r.status, g.status, 'status ' + g.input);
    assert.equal(r.start == null ? null : C.hm(r.start), g.start, 'start ' + g.input);
    assert.equal(r.end == null ? null : C.hm(r.end), g.end, 'end ' + g.input);
    assert.equal(r.subject, g.subject, 'subject ' + g.input);
    assert.deepEqual(r.candidates.map(([a, b]) => [C.hm(a), C.hm(b)]), g.candidates, 'cands ' + g.input);
  }
});
test('golden: schedules (overlay, conflicts, study minutes) match the Python reference', () => {
  golden.schedules.forEach((g, i) => {
    const es = g.entries.map((l, k) => ({ ...C.interpretEntry(l), id: k }));
    const out = C.applyEntries(C.baseRoutine(), es);
    assert.deepEqual(out.map((b) => [C.hm(b.start), C.hm(b.end), b.label, b.kind, b.prot]), g.blocks, 'blocks #' + i);
    assert.equal(C.studyMinutes(out), g.study_minutes, 'study #' + i);
    assert.deepEqual(C.validate(out), g.issues, 'issues #' + i);
  });
});
test('user example: no false conflict, study time recalculated', () => {
  const out = C.applyEntries(C.baseRoutine(), [C.interpretEntry('2:30pm to 3:45pm = Biology C')]);
  assert.ok(!out.some((b) => b.kind === 'conflict')); assert.equal(C.studyMinutes(out), 285);
  const out2 = C.applyEntries(C.baseRoutine(), [C.interpretEntry('4:15pm to 5:45pm = Physics extra')]);
  assert.equal(C.studyMinutes(out2), 195);
});
test('unresolved entries cannot be applied', () => {
  assert.throws(() => C.applyEntries(C.baseRoutine(), [C.interpretEntry('7:00 to 8:00 = Physics')]));
});
test('dates', () => {
  assert.equal(C.daysToExam('2026-11-12'), 171); assert.equal(C.daysToExam('2027-05-02'), 0);
  assert.equal(C.addDays('2026-12-30', 3), '2027-01-02'); assert.ok(C.isISO('2027-02-28')); assert.ok(!C.isISO('2027-02-30'));
});
test('data: calendars separate, Mathematics/Biology never invented for UT/TE', () => {
  const ut = DATA.tests.filter((t) => t.cal === 'UTTE'), ak = DATA.tests.filter((t) => t.cal === 'AAKASH');
  assert.equal(ut.length, 16); assert.equal(ak.length, 29);
  assert.equal(new Set(DATA.tests.map((t) => t.id)).size, 45, 'ids unique across calendars');
  for (const t of ut) assert.deepEqual(Object.keys(t.wording), ['Physics', 'Chemistry']);
  assert.equal(ut.find((t) => t.id === 'TE-1').date, null);
  assert.ok(DATA.tests.every((t) => !JSON.stringify(t.wording).includes('Mathematics')));
  const names = new Set(DATA.chapters.map((c) => c.chapter));
  for (const t of DATA.tests) for (const n of t.mapped) assert.ok(names.has(n), n);
  assert.equal(DATA.chapters.length, 84);
});
test('milestones are independent and only the latest event counts', () => {
  const s = C.emptyState(); s.milestones.push({ key: 'k', ms: 'revision_completed', done: true }, { key: 'k', ms: 'ncert_completed', done: true }, { key: 'k', ms: 'ncert_completed', done: false });
  const d = C.doneSet(C.milestoneState(s), 'k'); assert.deepEqual([...d], ['revision_completed']);
  assert.equal(C.nextStep('Physics', new Set()), 'first_reading_completed');
  assert.equal(C.nextStep('Botany', new Set(['first_reading_completed', 'ncert_completed'])), 'question_practice_completed'); // formulae skipped
});
test('tasks are ordered by earliest test; nothing is invented as complete', () => {
  const s = C.emptyState(), tasks = C.buildTasks(DATA, s, '2026-11-12', 21);
  assert.equal(tasks[0].testDate, '2026-11-14'); assert.equal(tasks[0].test, 'TE-2');
  assert.ok(tasks.every((t) => t.step === 'first_reading_completed'), 'no progress known => first step suggested');
  assert.ok(tasks.every((t, i) => i === 0 || tasks[i - 1].testDate <= t.testDate));
  assert.equal(s.milestones.length, 0);
});
test('week plan: fits only free study blocks, respects typed entries, is a pure proposal', () => {
  const s = C.emptyState(); s.entries.push({ id: 1, date: '2026-11-13', start: 15 * 60 + 45, end: 18 * 60, subject: 'Extra class', status: 'active' });
  const before = JSON.stringify(s), p = C.generateWeekPlan(DATA, s, '2026-11-12', 7);
  assert.equal(JSON.stringify(s), before, 'state untouched'); assert.equal(p.days.length, 7);
  for (const d of p.days) {
    assert.deepEqual(d.issues, []);
    const study = d.blocks.filter((b) => b.kind === 'study');
    for (const sl of d.slots) assert.ok(study.some((b) => sl.start >= b.start && sl.end <= b.end), 'slot inside a study block');
  }
  assert.equal(p.days[1].slots.filter((x) => x.start >= 15 * 60 + 45 && x.end <= 18 * 60).length, 0, 'typed class removed that day\'s self-study');
  assert.ok(p.assumptions.length >= 3);
});
test('today focus: overloaded => exactly ONE task', () => {
  const f = C.todayFocus(DATA, C.emptyState(), '2026-11-12', 7 * 60);
  assert.equal(f.mode, 'one'); assert.equal(f.tasks.length, 1); assert.equal(f.tasks[0].test, 'TE-2');
  const none = C.todayFocus(DATA, C.emptyState(), '2026-11-12', 23 * 60); assert.equal(none.tasks.length, 0);
});
test('upcoming tests honour date overrides and keep calendars apart', () => {
  const s = C.emptyState(); s.testDates['TE-1'] = '2026-11-20';
  const u = C.upcomingTests(DATA.tests, s, '2026-11-12', 'UTTE', 3).map((x) => x.t.id);
  assert.deepEqual(u, ['TE-2', 'UT-5', 'TE-1']);
  assert.ok(C.upcomingTests(DATA.tests, s, '2026-11-12', 'AAKASH', 3).every((x) => x.t.cal === 'AAKASH'));
});
test('backup: round trip, tamper and wrong-file detection', () => {
  const s = C.emptyState(); s.reports.push({ id: 1, ts: 't', body: 'हिन्दी ✓ text' });
  const txt = C.makeBackup(s, '2026-11-12T10:00:00Z'); assert.deepEqual(C.parseBackup(txt).reports, s.reports);
  assert.throws(() => C.parseBackup(txt.replace('text', 'tex7')), /checksum/); assert.throws(() => C.parseBackup('{"a":1}'), /Not a NEET/);
  assert.throws(() => C.parseBackup('garbage'), /unreadable/);
});
test('pin hash is salted and deterministic', () => {
  assert.equal(C.simpleHash('1234', 'a'), C.simpleHash('1234', 'a')); assert.notEqual(C.simpleHash('1234', 'a'), C.simpleHash('1234', 'b'));
});

test('plan never schedules into the past on the first day', () => {
  const p = C.generateWeekPlan(DATA, C.emptyState(), '2026-11-12', 7, 21, 10 * 60 + 2);
  assert.ok(p.days[0].slots.every((s) => s.start >= 10 * 60 + 5), 'first day starts after now');
  assert.ok(p.days[0].slots.length > 0); assert.equal(p.days[1].slots[0].start, 7 * 60, 'later days start normally');
});
test('plan states plainly when no progress is recorded, and the note disappears once chapters are ticked', () => {
  const none = C.generateWeekPlan(DATA, C.emptyState(), '2026-11-12', 7);
  assert.match(none.assumptions[0], /no milestone ticked/);
  const s = C.emptyState(); for (const t of C.buildTasks(DATA, s, '2026-11-12', 21)) s.milestones.push({ key: t.key, ms: 'learning_in_progress', done: true });
  assert.ok(!C.generateWeekPlan(DATA, s, '2026-11-12', 7).assumptions.some((a) => /no milestone ticked/.test(a)));
});
