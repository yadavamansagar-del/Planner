# NEET Offline v0.6 — working offline study manager

**What it is:** one self-contained file, `NEET_Offline.html` (92 KB). No internet, no accounts, no analytics, no external libraries. A built-in security policy forbids every network request.
**What it is not (yet):** an APK. No Android toolchain was available where this was built, so an APK could not be compiled. `android/` holds a small, **uncompiled and untested** wrapper that turns the same file into an installable app.

## Use it now on the Galaxy Tab A9
1. Copy `NEET_Offline.html` to the tablet.
2. Open it from the Files app with **Chrome**.
3. **Important:** Chrome may not keep saved data for a file opened this way. Settings shows a warning if storage is unavailable. Until you use the APK, press **Settings → Export backup** after every study session and keep the file. (Not yet tested on your tablet.)

## Build the installable app (APK)
Needs a computer with Android Studio (internet only for the build). Open `android/` → let it sync → Build → Debug APK → install on the tablet. Send me any error message and I will fix it. Plugin versions in the Gradle files are my unverified choice; accept Android Studio's upgrade suggestions.

## What it does
| Tab | Function |
|---|---|
| Today | Days to 2 May 2027, today's timetable (your routine), free study time left, next tests from both calendars. If more is due than time allows it shows **one** task only |
| Plan | Generates the whole 7-day plan first. It stays a proposal until you approve it; approved plans are never changed silently (old ones are kept as history) |
| Reports | Chat-style log, stored exactly as typed. Time entries such as `2:30pm to 3:45pm = Biology C` show an interpretation card and wait for Confirm. Unclear times (`7:00 to 8:00`) ask you to choose |
| Chapters | All 84 chapters, 8 independent milestone ticks (plus "not started"). Each tick asks for confirmation. Shows the next tests that cover the chapter |
| Tests | UT/TE calendar (Physics, Chemistry only) and Aakash calendar, kept completely separate. PDF wording preserved; chapter mapping and uncertainties flagged. TE-1 has no date in the PDF ("given as HA"): you can enter it |
| Settings | Storage status, checksummed backup export/import, recovery copies (last 5), milestone CSV export, PIN lock |

## Rules the app follows
Nothing is ticked, scheduled, approved or imported without your explicit confirmation. Nothing is deleted (entries are cancelled, plans superseded, milestone changes appended). Reports never change progress. No marks, dates or progress are invented: all chapters start unticked, so until you tick what you have finished, the plan suggests "First reading" for everything and says so.

## Not built (honest list)
- **Excel workbook link.** The app never opens or edits your workbook. Use the CSV export to copy milestones by hand. Safe write-back needs the Kotlin port of the OOXML engine (see `docs/AUDIT_v0_1_to_v0_5_bundles.md`).
- Weak-topic revision cycles, doubt re-attempts, question-practice log, score entry/analysis (these exist in your workbook, not here).
- Recurring weekly coaching schedule (entries are per date). Syllabus-to-chapter mapping is taken from your workbook and flagged for you to verify, not independently derived.
- The PIN is a casual lock, not encryption.

## Tests (run `tools/run_all_tests.sh`)
15 logic tests (including parity with the Python reference's golden vectors) + 31 checks in a real headless Chromium, with the clock fixed at 12 Nov 2026. See `VALIDATION.md`.
