#!/bin/sh
# Rebuild and run every test. Needs Node 22+. The browser test needs Playwright + Chromium (set PLAYWRIGHT_PATH if not global).
set -e
cd "$(dirname "$0")/.."
node tools/build.js
node --test tests/core.test.js
node tests/ui.e2e.js
