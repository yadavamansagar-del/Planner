// Inline data.js, core.js and ui.js into one self-contained NEET_Offline.html
const fs = require('fs'), path = require('path'), r = (f) => fs.readFileSync(path.join(__dirname, '..', 'src', f), 'utf8');
let html = r('template.html');
const put = (tag, code) => { if (code.includes('</script')) throw new Error('script terminator in ' + tag); html = html.replace('/*' + tag + '*/', () => code); };
put('DATA', r('data.js')); put('CORE', r('core.js')); put('UI', r('ui.js'));
const out = process.argv[2] || path.join(__dirname, '..', 'NEET_Offline.html'); fs.writeFileSync(out, html);
console.log('built', out, (html.length / 1024).toFixed(1) + ' KB');
