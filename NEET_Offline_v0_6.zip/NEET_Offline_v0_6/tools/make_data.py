"""Generate src/data.js: 84 chapters (from the workbook seed), UT/TE calendar and Aakash calendar.
Source wording typed from the two coaching PDFs (as supplied in the conversation). Mathematics is excluded
(user: not studied). 'mapped' chapter lists come from the user's corrected workbook Tests sheet and are flagged as such."""
import json, re, glob, warnings
from datetime import date, timedelta
warnings.simplefilter("ignore")
import openpyxl

seed = json.load(open('/home/claude/NEET_Offline_System_v0_5/data/chapters_seed.json'))
chapters = [{"key": c["key"], "subject": c["subject"], "chapter": c["chapter"]} for c in seed["chapters"]]
names = sorted({c["chapter"] for c in chapters}, key=len, reverse=True)
wb = openpyxl.load_workbook(glob.glob('/home/claude/v0_1/*/NEET_Planner_v2_CORRECTED_TEST_DATES.xlsx')[0], data_only=True)
ws = wb["Tests"]


def serial(v):
    if v in (None, ""):
        return None
    if hasattr(v, "date"):          # openpyxl returns datetime for date-formatted cells
        return v.date().isoformat()
    return (date(1899, 12, 30) + timedelta(days=int(v))).isoformat()


wbt = {}
for r in ws.iter_rows(min_row=5, values_only=True):
    if r[0]:
        scope = r[7] or ""
        found, rest = [], scope
        for n in names:  # longest-first so 'Thermodynamics (Physics)' wins over shorter names
            if n in rest:
                found.append(n)
                rest = rest.replace(n, "\0")
        wbt[r[0]] = {"date": serial(r[1]), "mapped": list(dict.fromkeys(found)), "complete": "Complete NEET-2027" in scope}

UTTE = [
    ("UT-1", "2026-10-15", "Physical World, Units & Measurement", "Structure of Atom"),
    ("UT-2", "2026-10-18", "Motion in a Straight Line", "Some Basic concept of Chemistry"),
    ("CT-1", "2026-10-22", "Physical World, Units & Measurement, Motion in a Straight Line", "Structure of Atom, Some Basic concept of Chemistry"),
    ("CT-2", "2026-10-25", "Motion in a Plane, Laws of Motion", "Classification of Elements and Periodicity, Chemical bonding and Molecular Structure"),
    ("TE-1", None, "Physical World, Units & Measurement, Motion in a Straight Line, Motion in a Plane, Laws of Motion", "Structure of Atom, Some Basic concept of Chemistry, Classification of Elements and Periodicity, Chemical bonding and Molecular Structure, States of Matter"),
    ("UT-3", "2026-11-03", "Work, Energy and Power, System of Particles and Rotational Motion", "Thermodynamics, Equilibrium"),
    ("UT-4", "2026-11-06", "Gravitation, Mechanical Properties of Solids, Mechanical Properties of Fluids", "Redox Reactions, Stoichiometry and Volumetric Analysis, Organic Chemistry - Some Basic Principles and Techniques"),
    ("TE-2", "2026-11-14", "Work, Energy and Power, System of Particles and Rotational Motion, Gravitation, Mechanical Properties of Solids, Mechanical Properties of Fluids", "Thermodynamics, Equilibrium, Redox Reactions, Stoichiometry and Volumetric Analysis, Organic Chemistry - Some Basic Principles and Techniques"),
    ("UT-5", "2026-11-19", "Thermal Properties of Matter, Thermodynamics, Kinetic Theory of Gases", "Hydrocarbons"),
    ("UT-6", "2026-11-24", "Oscillations, Waves", "The p-Block Elements (Group13, 14)"),
    ("UT-7", "2026-12-01", "Electric Charges and Field, Electrostatic Potential and Capacitance", "Solution, Electrochemistry"),
    ("UT-8", "2026-12-06", "Current Electricity, Moving charges and Magnetism", "Chemical Kinetics, The p-Block Elements (Group 15 - 18), The d & f-Block Elements"),
    ("UT-9", "2026-12-12", "Magnetism and Matter, Electromagnetic Induction", "Coordination Compounds, Haloalkanes and Haloarenes (including GOC)"),
    ("UT-10", "2026-12-18", "Alternating Current, Electromagnetic Waves, Ray Optics and Optical Instruments", "Alcohols, Phenols and Ethers, Aldehydes, Ketones and Carboxylic Acids"),
    ("UT-11", "2026-12-22", "Wave Optics, Dual Nature of Radiation & Matter, Atoms", "Amines, Biomolecules"),
    ("UT-12", "2026-12-26", "Nuclei, Semiconductor Electronics: Materials, Devices & Simple Circuits, Experimental Physics", "Surface Chemistry, Principles Related to Practical Chemistry including Qualitative Analysis"),
]
UTFLAGS = {
    "TE-1": ["PDF gives no date: 'Will be given as HA'. Enter the date when known.", "'States of Matter' has no chapter in your list (workbook says not in NEET-2027)."],
    "UT-1": ["'Physical World' is merged into Units & Measurements in the mapping."],
    "UT-4": ["'Stoichiometry and Volumetric Analysis' has no chapter in your list; the mapping omits it."],
    "TE-2": ["'Stoichiometry and Volumetric Analysis' has no chapter in your list; the mapping omits it."],
    "UT-6": ["'The p-Block Elements' is one chapter in your list; this test covers Groups 13, 14 only."],
    "UT-8": ["'The p-Block Elements' is one chapter in your list; this test covers Groups 15-18 only."],
    "UT-9": ["'including GOC': check whether GOC belongs to Haloalkanes or to 'Organic Chemistry: Basic Principles'."],
    "UT-12": ["'Surface Chemistry' has no chapter in your list (workbook says not in NEET-2027)."],
}
OPEN = "Open Mock Test on Complete Syllabus of NEET-2027"
AK = [
    ("FT-01", "2026-08-05", "Offline", "Units & Measurements, Motion in a Straight Line", "Some Basic Concepts of Chemistry", "Cell: The Unit of Life", "Structural Organisation in Animals– Animal Tissues; Biomolecules-I: (Upto polysaccharides)"),
    ("FT-02", "2026-08-26", "Offline", "Motion in a Plane, Laws of Motion", "Structure of Atom, Classification of Elements and Periodicity in Properties", "Cell Cycle & Cell Division, The Living World, Biological Classification-I: (Upto thermoacidophiles)", "Biomolecules-II: (Proteins, types & functions, Lipids, Nucleic acids, Enzymes, Cofactors), Breathing & Exchange of Gases-I: (Upto mechanism of breathing)"),
    ("Meridian-01", "2026-08-29", "Online", "Units & Measurements, Motion in a Straight Line, Motion in a Plane, Laws of Motion", "Some Basic Concepts of Chemistry, Structure of Atom, Classification of Elements and Periodicity in Properties", "Cell: The Unit of Life, Cell Cycle & Cell Division, The Living World, Biological Classification-I: (Upto thermoacidophiles)", "Structural Organisation in Animals– Animal Tissues Biomolecules, Breathing & Exchange of Gases-I: (Upto mechanism of breathing)"),
    ("FT-03", "2026-09-23", "Offline", "Work, Energy & Power, System of Particles & Rotational Motion", "Chemical Bonding and Molecular Structure, Thermodynamics", "Biological Classification-II: (from Cyanobacteria to Lichens), Morphology of Flowering Plants", "Breathing & Exchange of Gases-II: (Upto disorders), Body Fluids & Circulation"),
    ("NBTS_R-01", "2026-09-30", "Online/CBT", "Units & Measurements, Motion in a Straight Line, Motion in a Plane, Laws of Motion, Work, Energy & Power, System of Particles & Rotational Motion", "Some Basic Concepts of Chemistry, Structure of Atom, Classification of Elements and Periodicity in Properties, Chemical Bonding and Molecular Structure, Thermodynamics", "Cell: The Unit of Life, Cell Cycle & Cell Division, The Living World, Biological Classification, Morphology of Flowering Plants", "Structural Organisation in Animals– Animal Tissues Biomolecules, Breathing & Exchange of Gases, Body Fluids & Circulation"),
    ("AIATS Practice-01", "2026-10-25", "Online", "Units & Measurements, Motion in a Straight Line, Motion in a Plane", "Some Basic Concepts of Chemistry, Structure of Atom", "Cell: the Unit of Life, Cell Cycle and Cell Division, The Living World", "Structural Organisation in Animals–Animal Tissues, Biomolecules"),
    ("AIATS-01", "2026-11-01", "Offline", "Units & Measurements, Motion in a Straight Line, Motion in a Plane", "Some Basic Concepts of Chemistry, Structure of Atom", "Cell: The Unit of Life, Cell Cycle and Cell Division, The Living World", "Structural Organisation in Animals–Animal Tissues, Biomolecules"),
    ("FT-04", "2026-11-04", "Offline", "Gravitation, Mechanical Properties of Solids, Mechanical Properties of Fluids", "Equilibrium, Redox Reactions, Electrochemistry", "Anatomy of Flowering Plants, Plant Kingdom", "Excretory Products & their Elimination, Locomotion & Movement"),
    ("Meridian-02", "2026-11-08", "Online", "Work, Energy & Power, System of Particles & Rotational Motion, Gravitation, Mechanical Properties of Solids, Mechanical Properties of Fluids", "Chemical Bonding and Molecular Structure, Thermodynamics, Equilibrium, Redox Reactions, Electrochemistry", "Biological Classification-II: (from Cyanobacteria to Lichens), Morphology of Flowering Plants, Anatomy of Flowering Plants, Plant Kingdom", "Breathing & Exchange of Gases-II: (Upto disorders), Body Fluids & Circulation, Excretory Products & their Elimination, Locomotion & Movement"),
    ("AIATS-02", "2026-11-29", "Offline", "Laws of Motion; Work, Energy and Power", "Classification of Elements and periodicity in properties, Chemical Bonding and molecular structure", "Biological Classification, Morphology of Flowering Plants", "Breathing & Exchange of Gases, Body Fluids & Circulation"),
    ("FT-05", "2026-12-09", "Offline", "Thermal Properties of Matter, Thermodynamics, Kinetic Theory, Oscillations, Waves", "Solutions, Chemical Kinetics, Organic Chemistry: Some Basic Principle & Techniques", "Photosynthesis in Higher Plants, Respiration in Plants", "Neural Control & Coordination, Chemical Coordination & Integration"),
    ("AIATS-03", "2026-12-27", "Offline", "System of Particles and Rotational Motion, Gravitation, Mechanical Properties of Solids, Mechanical Properties of Fluids", "Thermodynamics, Equilibrium, Redox Reactions, Electrochemistry", "Anatomy of Flowering Plants, Plant Kingdom", "Excretory Products & their Elimination, Locomotion & Movement, Neural Control & Coordination"),
    ("FT-06", "2027-01-06", "Offline", "Electric Charges & Fields, Electrostatic Potential and Capacitance, Current Electricity", "Hydrocarbons, Haloalkanes and Haloarenes", "Plant Growth and Development, Sexual Reproduction in Flowering Plants", "Animal Kingdom, Structural Organisation in Animals– Animal Morphology (Cockroach & Frog)"),
    ("Meridian-03", "2027-01-10", "Online", "Thermal Properties of Matter, Thermodynamics, Kinetic Theory, Oscillations, Waves, Electric Charges & Fields, Electrostatic Potential and Capacitance, Current Electricity", "Solutions, Chemical Kinetics, Organic Chemistry: Some Basic Principle & Techniques, Hydrocarbons, Haloalkanes and Haloarenes", "Photosynthesis in Higher Plants, Respiration in Plants, Plant Growth and Development, Sexual Reproduction in Flowering Plants", "Neural Control & Coordination, Chemical Coordination & Integration, Animal Kingdom, Structural Organisation in Animals– Animal Morphology (Cockroach & Frog)"),
    ("NBTS_R-02", "2027-01-13", "Online/CBT", "Gravitation, Mechanical Properties of Solids, Mechanical Properties of Fluids, Thermal Properties of Matter, Thermodynamics, Kinetic Theory, Oscillations, Waves, Electric Charges & Fields, Electrostatic Potential and Capacitance, Current Electricity", "Equilibrium, Redox Reactions, Electrochemistry, Solutions, Chemical Kinetics, Organic Chemistry: Some Basic Principle & Techniques, Hydrocarbons, Haloalkanes and Haloarenes", "Anatomy of Flowering Plants, Plant Kingdom, Photosynthesis in Higher Plants, Respiration in Plants, Plant Growth and Development, Sexual Reproduction in Flowering Plants", "Excretory Products & their Elimination, Locomotion & Movement, Neural Control & Coordination, Chemical Coordination & Integration, Animal Kingdom, Structural Organisation in Animals– Animal Morphology (Cockroach & Frog)"),
    ("AIATS-04", "2027-01-17", "Offline", "Thermal Properties of Matter, Thermodynamics, Kinetic Theory, Oscillations, Waves", "Solutions, Chemical Kinetics, Organic Chemistry- Some Basic Principles and Techniques", "Photosynthesis in Higher plants, Respiration in Plants, Plant Growth and Development", "Chemical Coordination & Integration, Animal Kingdom, Structural Organisation in Animals– Animal Morphology (Cockroach & Frog)"),
    ("FT-07", "2027-02-03", "Offline", "Moving Charges and Magnetism, Magnetism and Matter, Electromagnetic Induction", "Alcohols, Phenols and Ethers, Aldehydes, Ketones and Carboxylic Acids", "Principles of Inheritance & Variation, Molecular Basis of Inheritance I: From introduction to DNA replication", "Human Reproduction, Reproductive Health"),
    ("AIATS-05", "2027-02-07", "Offline", "Electric Charges & Fields, Electrostatic Potential and Capacitance, Current Electricity", "Hydrocarbons, Haloalkanes and Haloarenes, Alcohols, Phenols and Ethers, Aldehydes, Ketones and Carboxylic Acids", "Sexual Reproduction in Flowering Plants, Principles of Inheritance & Variation", "Human Reproduction, Reproductive Health"),
    ("FT-08", "2027-02-24", "Offline", "Alternating Current, Electromagnetic Waves, Ray Optics & Optical Instruments, Wave Optics", "Amines (Organic Compound containing Nitrogen), The d & f Block Elements, Coordination Compounds", "Molecular Basis of Inheritance II: From transcription to DNA fingerprinting, Microbes in Human Welfare", "Evolution, Human Health & Diseases"),
    ("Meridian-04", "2027-02-28", "Online", "Moving Charges and Magnetism, Magnetism and Matter, Electromagnetic Induction, Alternating Current, Electromagnetic Waves, Ray Optics & Optical Instruments, Wave Optics", "Alcohols, Phenols and Ethers, Aldehydes, Ketones and Carboxylic Acids, Amines (Organic Compound containing Nitrogen), The d & f Block Elements, Coordination Compounds", "Principles of Inheritance & Variation, Molecular Basis of Inheritance, Microbes in Human Welfare", "Human Reproduction, Reproductive Health, Evolution, Human Health & Diseases"),
    ("AIATS-06", "2027-03-07", "Offline", "Moving Charges and Magnetism, Magnetism and Matter, Electromagnetic Induction, Alternating Current, Electromagnetic Waves", "Amines, The d & f-Block Elements, Coordination Compounds", "Molecular Basis of Inheritance, Microbes in Human Welfare", "Evolution, Human Health & Disease"),
    ("FT-09", "2027-03-10", "Offline", "Dual Nature of Radiation and Matter, Atoms, Nuclei, Semiconductor, Experimental Skills", "The p-Block Elements, Biomolecules, Principles Related to Practical Chemistry", "Organisms and Populations, Ecosystem, Biodiversity and Conservation", "Biotechnology: Principles & Processes, Biotechnology & Its Applications"),
    ("Meridian-05", "2027-03-14", "Online", "Dual Nature of Radiation and Matter, Atoms, Nuclei, Semiconductor, Experimental Skills", "The p-Block Elements, Biomolecules, Principles Related to Practical Chemistry", "Organisms and Populations, Ecosystem, Biodiversity and Conservation", "Biotechnology: Principles & Processes, Biotechnology & Its Applications"),
    ("NBTS_R-03", "2027-03-17", "Online/CBT", "Moving Charges and Magnetism, Magnetism and Matter, Electromagnetic Induction, Alternating Current, Electromagnetic Waves, Ray Optics & Optical Instruments, Wave Optics, Dual Nature of Radiation and Matter, Atoms, Nuclei, Semiconductor, Experimental Skills", "Alcohols, Phenols and Ethers, Aldehydes, Ketones and Carboxylic Acids, Amines (Organic Compound containing Nitrogen), The d & f Block Elements, Coordination Compounds, The p-Block Elements, Biomolecules, Principles Related to Practical Chemistry", "Principles of Inheritance & Variation, Molecular Basis of Inheritance, Microbes in Human Welfare, Organisms and Populations, Ecosystem, Biodiversity and Conservation", "Human Reproduction, Reproductive Health,Evolution, Human Health & Diseases, Biotechnology: Principles & Processes, Biotechnology & Its Applications"),
    ("AIATS-07", "2027-03-21", "Offline", "Ray Optics & Optical Instruments, Wave Optics, Dual Nature of Matter and Radiation; Atoms, Nuclei; Semiconductors, Experimental Skills", "The p-Block Elements, Biomolecules, Principles Related to Practical Chemistry", "Organisms and Populations, Ecosystem, Biodiversity and Conservation", "Biotechnology-Principles and Processes, Biotechnology and its Applications"),
    ("AIATS-08", "2027-04-04", "Online/CBT", OPEN, OPEN, OPEN, OPEN),
    ("AIATS-09", "2027-04-11", "Online/CBT", OPEN, OPEN, OPEN, OPEN),
    ("AIATS-10", "2027-04-18", "Online/CBT", OPEN, OPEN, OPEN, OPEN),
    ("AIATS-11", "2027-04-25", "Online/CBT", OPEN, OPEN, OPEN, OPEN),
]
RANGES = {"Meridian-01": "2026-08-31", "Meridian-02": "2026-11-10", "Meridian-03": "2027-01-12", "Meridian-04": "2027-03-02", "Meridian-05": "2027-03-16"}
PARTIAL = re.compile(r"Upto|\(from |Biomolecules-I|-I:|-II:| I:| II:")
MAPNOTE = "Chapter mapping comes from your workbook, not from the PDF: verify."
tests = []
for tid, d, p, c in UTTE:
    w = wbt.get(tid, {})
    tests.append({"id": tid, "cal": "UTTE", "date": d, "end": None, "mode": "Offline", "wording": {"Physics": p, "Chemistry": c},
                  "mapped": w.get("mapped", []), "complete": False, "flags": UTFLAGS.get(tid, []) + [MAPNOTE]})
for tid, d, mode, p, c, b, z in AK:
    w = wbt.get(tid, {})
    fl = []
    if PARTIAL.search(" ".join([p, c, b, z])):
        fl.append("Source wording names part of a chapter; the mapping lists the whole chapter.")
    if "Biological Classification," in b:
        fl.append("'Biological Classification' is unsplit in the PDF; mapped to I and II.")
    if "Biomolecules" in z:
        fl.append("'Biomolecules' appears under Zoology here and under Chemistry elsewhere (two chapters in your list).")
    fl.append(MAPNOTE)
    tests.append({"id": tid, "cal": "AAKASH", "date": d, "end": RANGES.get(tid), "mode": mode,
                  "wording": {"Physics": p, "Chemistry": c, "Botany": b, "Zoology": z},
                  "mapped": w.get("mapped", []), "complete": w.get("complete", False), "flags": fl})

bad = [(t["id"], t["date"], wbt[t["id"]]["date"]) for t in tests
       if t["id"] in wbt and t["date"] and wbt[t["id"]]["date"] and t["date"] != wbt[t["id"]]["date"]]
print("date mismatches vs workbook:", bad or "none")
print("tests:", len(tests), "UTTE:", sum(t["cal"] == "UTTE" for t in tests), "AAKASH:", sum(t["cal"] == "AAKASH" for t in tests))
print("tests with no mapped chapters (excluding complete-syllabus):", [t["id"] for t in tests if not t["mapped"] and not t["complete"]])
print("workbook test ids not in my calendars:", sorted(set(wbt) - {t["id"] for t in tests}))
json.dump({"chapters": chapters, "tests": tests}, open("/home/claude/neet_app/src/data.json", "w"), ensure_ascii=False)
open("/home/claude/neet_app/src/data.js", "w", encoding="utf-8").write(
    "window.NEET_DATA = " + json.dumps({"chapters": chapters, "tests": tests}, ensure_ascii=False) + ";\n")
